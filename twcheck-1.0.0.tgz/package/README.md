# twcheck

Find and fix non-canonical Tailwind CSS classes using Tailwind-style canonical forms.

## Usage

```bash
npx twcheck src
npx twcheck src --diff
npx twcheck src --fix
npx twcheck . --check
npx twcheck src --json
npx twcheck src --css src/styles/globals.css
```

The default mode is read-only. `--diff` previews exact replacements, `--fix` writes them, and `--check` returns exit code `1` when warnings are found. Runtime or configuration errors return exit code `2`.

V1 scans supported source files recursively, respects `.gitignore`, and skips generated folders including `node_modules`, `.next`, `dist`, `build`, `out`, and `coverage`.

## Options

`<path>` accepts a file, directory, or `.`. Available flags are `--diff`, `--fix`, `--check`, `--json`, `--css <file>`, `--help`, and `--version`.

## License

MIT
